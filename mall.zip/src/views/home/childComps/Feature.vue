<template>
    <div class="feature">
        <img src="~assets/img/home/recommend_bg.jpg">
    </div>
</template>

<script>
    export default {
        name: "Feature"
    }
</script>

<style scoped>
    .feature{
        width: 100%;
    }
    .feature img{
        width: 100%;
    }

</style>