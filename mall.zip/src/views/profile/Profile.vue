<template>
    <h2>个人</h2>
</template>

<script>
    export default {
        name: "Account"
    }
</script>

<style scoped>

</style>