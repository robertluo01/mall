/**
 * Created by Administrator on 2021/6/10.
 */

export default {
    cartLength(state){
        return state.cartList.length
    },

    cartList(state){
        return state.cartList;
    }
}
