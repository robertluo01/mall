<template>
    <div class="back-top">
        <img src="~assets/img/common/top.png" alt="">
    </div>

</template>

<script>
    export default {
        name: "backTop"
    }
</script>

<style scoped>
    .back-top img{
        position: fixed;
        width: 43px;
        bottom: 55px;
        right: 10px;
    }

</style>