<template>
    <div class="check-button" :class="{check:isChecked}">
        <img src="~assets/img/cart/tick.svg" alt="" >
    </div>
    
    
</template>

<script>
    export default {
        name: "CheckButton",
        props : {
            isChecked : {
                type:Boolean,
                default:true
            }
        }
    }
</script>

<style scoped>
    .check-button{
        /*background-color: red;*/
        border-radius: 50%;
        border: 2px solid #aaa;
        overflow: hidden;
    }
    .check{
        border-color: red;
        background-color: red;

    }

</style>